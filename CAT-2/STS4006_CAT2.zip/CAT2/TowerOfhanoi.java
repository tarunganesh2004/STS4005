import java.util.*;
import java.io.*;

public class Main{
  public void solve(int n, int from, int to, int aux){
    if(n == 1){
      System.out.println("Move disk 1 from rod " + from + " to rod " + to);
      return;
    }
    solve(n-1, from, aux, to);
    System.out.println("Move disk " + n + " from rod " + from + " to rod " + to);
    solve(n-1, aux, to, from);
  }
  public static void main(String[] args) {
    var sc = new Scanner(System.in);
    var main = new Main();
    int val = sc.nextInt();
    main.solve(val, 1, 3, 2); 
    sc.close();
  }
}
