import java.io.*;
import java.util.*;

public class LoopDetection2 {
  class Node {
    Node next;
    int val;

    public Node(int val, Node next) {
      this.next = next;
      this.val = val;
    }
  }

  public boolean isLooping(Node head) {
    var slow = head;
    var fast = head;

    while (fast != null && fast.next != null) {
      fast = fast.next.next;
      slow = slow.next;
      if (fast == slow)
        return true;
    }

    return false;
  }

  public static void main(String[] args) {
    var sc = new Scanner(System.in);
    var main = new LoopDetection2();

    int[] arr = Arrays.stream(
        sc.nextLine().split(" "))
        .mapToInt(Integer::parseInt)
        .toArray();

    Node head = main.arrToLL(arr);

    int[] linkArr = Arrays.stream(
        sc.nextLine().split(" "))
        .mapToInt(Integer::parseInt)
        .toArray();

    int from = linkArr[0];
    int to = linkArr[1];

    if (from != 0 && to != 0)
      main.putLink(head, from, to);

    System.out.println(main.isLooping(head) ? "Is Looping" : "Isn't looping");

    sc.close();
  }

  Node arrToLL(int[] arr) {
    var head = new Node(-1, null);
    var temp = head;
    for (var i : arr) {
      var n = new Node(i, null);
      temp.next = n;
      temp = temp.next;
    }
    return head.next;
  }

  void putLink(Node head, int from, int to) {
    if (head == null)
      return;

    var fromNode = head;
    while (fromNode != null) {
      if (fromNode.val == from)
        break;
      fromNode = fromNode.next;
    }

    var toNode = head;
    while (toNode != null) {
      if (toNode.val == to)
        break;
      toNode = toNode.next;
    }

    fromNode.next = toNode;
  }
}
