import java.util.*;
import java.io.*;

public class Main {

  public int findCeleb(int[][] graph){
    int N = graph.length;
    var s = new Stack<Integer>();
    for(int i = 0; i<N; i++)
      s.push(i);

    while(s.size() > 1){
      var e1 = s.pop(); 
      var e2 = s.pop();
      var e1KnowsE2 = graph[e1][e2] == 1;

      if(e1KnowsE2) s.push(e2);
      else s.push(e1);
    }

    int idx = s.pop(); // possible celeb index 
    for(int i = 0; i<N; i++) {
      if(i == idx) continue; 
      var curr = i;
      var idxKnowsCurr = graph[idx][curr] == 1;
      var currKnowsIdx = graph[curr][idx] == 1;
      if(!currKnowsIdx || idxKnowsCurr) return -1;
    }

    return idx;
  }

  public static void main(String[] args) {
    var sc = new Scanner(System.in);
    int numRows = Integer.parseInt(sc.nextLine());
    var main = new Main();

    // taking the celeb graph as input
    int[][] graph = new int[numRows][numRows];
    for (int i = 0; i < numRows; i++) {
      int[] arr = Arrays.stream(sc.nextLine().split(" "))
          .mapToInt(Integer::parseInt)
          .toArray();
      graph[i] = arr;
    } 

    System.out.println(main.findCeleb(graph));

    sc.close();
  }
}
