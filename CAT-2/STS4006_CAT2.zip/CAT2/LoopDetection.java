import java.util.*;
import java.io.*;

public class LoopDetection {
  class Node {
    Node next;
    int val;

    public Node(Node next, int val) {
      this.next = next;
      this.val = val;
    }
  }

  public boolean findLoop(Node head){
    var slow = head;
    var fast = head;
    while(fast != null && fast.next !=null){
      if(fast == slow){
        return true;
      }
      fast = fast.next.next;
      slow = slow.next;
    }
    return false;
  }

  public static void main(String[] args) {
    var sc = new Scanner(System.in);
    var main = new LoopDetection();
    System.out.print("Enter the nodes in the linked list: ");
    var arr = Arrays.stream(
        sc.nextLine().split(" "))
        .mapToInt(Integer::parseInt)
        .toArray();

    System.out.print("Enter from, to link: ");
    var linkArr = Arrays.stream(
        sc.nextLine().split(" "))
        .mapToInt(Integer::parseInt)
        .toArray();

    var from = linkArr[0];
    var to = linkArr[1];

    // arr -> linkArr
    var ll = main.arrToLL(arr);

    // putting the loop
    main.putLoop(ll, from, to);

    // printing the list 
    System.out.println(main.print(ll));

    // Printing is loop
    System.out.println(main.findLoop(ll));

    sc.close();
  }

  Node arrToLL(int[] arr) {
    Node head = new Node(null, -1);
    var temp = head;
    for (var i : arr) {
      var tmp = new Node(null, i);
      temp.next = tmp;
      temp = temp.next;
    }
    return head.next;
  }

  void putLoop(Node head, int from, int to) {

    // putting the loop in
    //
    // finding the from node
    var fromNode = head;
    while (fromNode != null) {
      if (fromNode.val == from)
        break;
      fromNode = fromNode.next;
    }

    // finding the to node
    var toNode = head;
    while (toNode != null) {
      if (toNode.val == to)
        break;
      toNode = toNode.next;
    }

    fromNode.next = toNode;
  }

  public String print(Node head) {
    var sb = new StringBuilder();
    var s = new HashSet<Node>();
    var temp = head;
    while (temp.next != null) {
      if (s.contains(temp)) {
        sb.append(" (loop) ");
        break;
      }
      s.add(temp);
      sb.append(temp.val);
      sb.append(" -> ");
      temp = temp.next;
    }
    sb.append(temp.val);

    return sb.toString();
  }
}
