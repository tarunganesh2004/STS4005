import java.util.*;
import java.io.*;

public class StackPermutation2 {
  public static boolean isPerm(Queue<Integer> q1, Queue<Integer> q2) {
    Stack<Integer> temp = new Stack<>();
    while (!q1.isEmpty()) {
      var ele = q1.poll();
      if (ele == q2.peek()) {
        q2.poll();
        while (!temp.isEmpty()) {
          if (temp.peek() == q2.peek()) {
            temp.pop();
            q2.poll();
          } else {
            break;
          }
        }
      } else {
        temp.push(ele);
      }
    }

    return (q1.isEmpty() && temp.isEmpty());
  }

  public static void main(String[] args) {
    var sc = new Scanner(System.in);
    int[] arr = Arrays.stream(sc.nextLine().split(" "))
        .mapToInt(Integer::parseInt)
        .toArray();

    int[] arr2 = Arrays.stream(sc.nextLine().split(" "))
        .mapToInt(Integer::parseInt)
        .toArray();

    Queue<Integer> q1 = qfromArr(arr);
    Queue<Integer> q2 = qfromArr(arr2);

    System.out.println(isPerm(q1, q2));

    sc.close();
  }

  static Queue<Integer> qfromArr(int[] arr){
    Queue<Integer> q = new LinkedList<>();
    for(int i : arr){
      q.add(i);
    }
    return q;
  }
}
