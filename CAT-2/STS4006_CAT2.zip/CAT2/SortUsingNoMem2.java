import java.util.*;
import java.io.*;

public class SortUsingNoMem2{
  public void sort(Queue<Integer> q){
    for(int i = 0; i < q.size(); i++){
      int min_index = findMin(q, q.size() - i);
      System.out.println(min_index);
      pushMinToBack(q, min_index);
    }
  }
  public static void main(String[] args) {
    var sc = new Scanner(System.in);
    var arr = Arrays.stream(sc.nextLine().split(" "))
      .mapToInt(Integer::parseInt) 
      .toArray();
    Queue<Integer> q = new LinkedList<>();
    for(int i: arr)
      q.add(i);
    var main = new SortUsingNoMem2();
    main.sort(q);
    for(int i: q){
      System.out.print(i + " ");
    }
    sc.close();
  }

  void pushMinToBack(Queue<Integer> q, int mIndex){
    var s = q.size();
    var minVal = -1;
    for(int i=0; i<s; i++){
      int val = q.poll();
      if(i == mIndex)
        minVal = val;
      else
        q.add(val);
    }
    q.add(minVal);
  }

  int findMin(Queue<Integer> q, int mIndex){
    int s = q.size();
    int minVal = Integer.MAX_VALUE;
    int minIndex = -1;
    for(int i = 0; i<s; i++){
      int val = q.poll();
      if(val <= minVal && i < mIndex){
        minVal = val;
        minIndex = i;
      }
      q.add(val);
    }
    return minIndex;
  }
}
