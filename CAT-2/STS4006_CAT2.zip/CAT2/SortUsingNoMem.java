import java.util.*;
import java.io.*;

public class SortUsingNoMem{
  class Node{
    int val; 
    Node next;

    public Node(int val){this.val = val;}
  }

  public int minIndex(Queue<Integer> q, int sortedIndex){
    int min_index = -1;
    int min_val = Integer.MAX_VALUE; 
    int s = q.size();
    for(int i = 0; i<s; i++){
      int curr = q.peek(); q.poll();
      if(curr <= min_val && i < sortedIndex){
        min_index = i; 
        min_val = curr;
      }
      q.add(curr);
    }
    return min_index;
  }

  public void insertMinToRear(Queue<Integer> q, int min_index){
    int min_val = 0;
    int s = q.size();
    for(int i=0; i<s; i++){
      int curr = q.peek(); q.poll();
      if(i != min_index)
        q.add(curr);
      else
        min_val = curr;
    }
    q.add(min_val);
  }

  public void sortQ(Queue<Integer> q){
    for(int i = 0; i < q.size(); i++){
      int min_index = minIndex(q, q.size()- i);
      System.out.println(min_index);
      insertMinToRear(q, min_index);
    }
  }

  public static void main(String[] args) {
    var sc = new Scanner(System.in);
    int[] arr = Arrays.stream(sc.nextLine().split(" "))
      .mapToInt(Integer::parseInt)
      .toArray();
    var main = new SortUsingNoMem();
    Queue<Integer> list = new LinkedList<Integer>();
    for(int i : arr){
      list.add(i);
    }
    main.sortQ(list);
    for(int i : list){
      System.out.print(i + " ");
    }
    sc.close();
  }
}
