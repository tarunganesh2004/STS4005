import java.util.*;
import java.io.*;

public class MergeSortDLL{
  class Node{
    Node prev;
    Node next;
    int val; 

    public Node(int val){ this.val = val; }
  }

  public Node mergeSort(Node head){
    if(head == null) return head; 
    if(head.next == null) return head;

    var p2 = split(head);
    var p1 = head;

    var sp1 = mergeSort(p1);
    var sp2 = mergeSort(p2);

    return merge(sp1, sp2);
  }

  public Node split(Node head){
    if(head == null) return null;
    var fast = head;
    var slow = head; 
    while(fast.next != null && fast.next.next != null){
      fast = fast.next.next;
      slow = slow.next;
    }
    var temp = slow.next;
    slow.next = null;
    return temp;
  }

  public Node merge(Node l1, Node l2){
    if(l1 == null) return l2;
    if(l2 == null) return l1;

    if(l1.val < l2.val){
      l1.next = merge(l1.next, l2);
      l1.next.prev = l1;
      l1.prev = null;
      return l1;
    }else{
      l2.next = merge(l1, l2.next);
      l2.next.prev = l2;
      l2.prev = null;
      return l2;
    }
  }

  public static void main(String[] args) {
    var sc = new Scanner(System.in);
    int[] arr = Arrays.stream(sc.nextLine().split(" "))
      .mapToInt(Integer::parseInt)
      .toArray();
    var main = new MergeSortDLL();
    Node head = main.toDll(arr);

    var ll = main.mergeSort(head);
    System.out.println(main.print(ll));

    sc.close();
  }

  Node toDll(int[] arr){
    var head = new Node(-1);
    var temp = head;
    
    for(var i : arr){
      var nn = new Node(i);
      temp.next = nn;
      nn.prev = temp; 
      temp = temp.next;
    }
    head.next.prev = null;
    return head.next;
  }

  public String print(Node head) {
    var sb = new StringBuilder();
    var s = new HashSet<Node>();
    var temp = head;
    while (temp.next != null) {
      if (s.contains(temp)) {
        sb.append(" (loop) ");
        break;
      }
      s.add(temp);
      sb.append(temp.val);
      sb.append(" <=> ");
      temp = temp.next;
    }
    sb.append(temp.val);

    return sb.toString();
  }
}
