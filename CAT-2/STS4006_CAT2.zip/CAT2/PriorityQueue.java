import java.util.*;
import java.io.*;

public class PriorityQueue{
  class Node{
    int id;
    int val;
    Node next;

    public Node(int id, int val){
      this.id = id;
      this.val = val;
    }
  }
  public static void main(String[] args) {
    var sc = new Scanner(System.in);
    var main = new PriorityQueue();
    var numLines = Integer.parseInt(sc.nextLine());
    var nodesList = new Node[numLines];

    for(int i = 0; i< numLines; i++){
      nodesList[i] = main.readSingleLine(sc);
    }

    var pq = main.newNode();
    for(var i: nodesList){
      main.insert(pq, i);
      System.out.println(main.print(pq));
    }
    sc.close();
  }

  public Node newNode(){
    return new Node(-1, -1);
  }

  public void insert(Node pq,Node node){
    var temp = pq; 
    while(temp.next != null && temp.next.val < node.val){
      temp = temp.next;
    }
    var next = temp.next;
    temp.next = node;
    node.next = next;
  }

  public String print(Node head) {
    var sb = new StringBuilder();
    var s = new HashSet<Node>();
    sb.append("| id | pq |\n");
    var temp = head;
    while (temp != null) {
      if (s.contains(temp)) {
        sb.append(" (loop) ");
        break;
      }
      s.add(temp);
      sb.append("| " + temp.id + "| " + temp.val + "|\n");
      temp = temp.next;
    }
    // sb.append(temp.val);

    return sb.toString();
  }

  public Node readSingleLine(Scanner sc){
    var line = sc.nextLine().split(" ");
    int id = Integer.parseInt(line[0]);
    int val = Integer.parseInt(line[1]);
    return new Node(id, val);
  }
}
