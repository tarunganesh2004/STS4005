import java.io.*;
import java.util.*;

public class SortBitonicDll{

  class Node{
    Node prev; 
    Node next; 
    int val ;

    public Node(int val){ this.val = val; }
  }

  public Node sortBitonicDll(Node head){
    var end = head;
    while(end.next != null){
      end = end.next;
    }

    var start = head;
    var temp = new Node(-1);
    var res = temp;

    while(start != end){
      if(start.val < end.val){
        res.next = start;
        start.prev = res;
        start = start.next;
      }else{
        res.next = end;
        var prev = end.prev;
        end.prev = res;
        end = prev;
      }
      res = res.next;
    }
    
    res.next = start;
    start.prev = res;
    start.next = null;
     
    return temp;
  }

  public static void main(String[] args) {
    var sc = new Scanner(System.in);
    var arr = Arrays.stream(sc.nextLine().split(" "))
      .mapToInt(Integer::parseInt)
      .toArray();
  
    var main = new SortBitonicDll();
    Node head = main.arrToLL(arr);
    System.out.println(main.print(head));
    System.out.println(main.print(main.sortBitonicDll(head)));

    sc.close();
  }

  Node arrToLL(int[] arr){
    var head = new Node(-1);
    var temp = head; 

    for(var i: arr){
      var nn = new Node(i);
      nn.prev = temp; 
      temp.next = nn;
      temp = temp.next;
    }

    head.next.prev = null;
    return head.next;
  }

  public String print(Node head) {
    var sb = new StringBuilder();
    var s = new HashSet<Node>();
    var temp = head;
    while (temp.next != null) {
      if (s.contains(temp)) {
        sb.append(" (loop) ");
        break;
      }
      s.add(temp);
      sb.append(temp.val);
      sb.append(" <=> ");
      temp = temp.next;
    }
    sb.append(temp.val);

    return sb.toString();
  }
}
