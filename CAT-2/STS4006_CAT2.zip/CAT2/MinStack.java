import java.util.*;
import java.io.*;

public class MinStack{
  Stack<Integer> stack = new Stack<>();
  Stack<Integer> minStack = new Stack<>();

  void insert(int val){
    stack.push(val);
    if(minStack.isEmpty() || val < minStack.peek()){
      minStack.push(val);
    }
  }

  int pop(){
    var ele = stack.pop();
    if(ele == minStack.peek()){
      minStack.pop();
    }
    return ele;
  }
}
