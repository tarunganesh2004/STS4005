import java.util.*;

public class MajorityElement {
  public MajorityElement() {
    super();
  }

  public static int hashMapItr(int[] arr){
    var countMap = new HashMap<Integer, Integer>();

    // putting default values in the hashmap
    for (int i = 0; i < arr.length; i++)
      countMap.put(arr[i], 0);
  
    // couting the values 
    for (int i : arr) {
      int value = countMap.get(i) + 1;
      countMap.put(i, value);
    }

    // getting the max key 
    var k = Collections.max(countMap.entrySet(), Map.Entry.comparingByValue()).getKey();

    System.out.println(k);
    return k;
  }

  public static int boyerMooreMethod(int[] arr){
    int count = 0; 
    int candidate = -1;

    for(var val : arr){
      if(count == 0){
        count += 1;
        candidate = val;
        continue;
      }
      if(val == candidate){
        count++;
        continue;
      }
      count--;
    }

    return candidate;
  }

  public static void main(String[] args) {
    // reading the input
    var sc = new Scanner(System.in);
    var line = sc.nextLine().split(" ");
    // reading the array
    int[] arr = Arrays.stream(line).mapToInt(Integer::parseInt).toArray();
    int res = boyerMooreMethod(arr);
    System.out.println(res);
  }
}
