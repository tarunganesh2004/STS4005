import java.util.*;

public class HamiltonianPath {
  public HamiltonianPath() {
    super();
  }

  static int NOT_VISITED = -1;
  static int VISITED = 0;
  static int CONNECTED = 1;

  public static void main(String[] args) {
    // var sc = new Scanner(System.in);
    // var line = sc.nextLine();
    var graph = new int[][] {
        { 0, 1, 0, 1, 0 },
        { 1, 0, 1, 1, 1 },
        { 0, 1, 0, 0, 1 },
        { 1, 1, 0, 0, 1 },
        { 0, 1, 1, 1, 0 }
    };

    var hp = new HamiltonianPath();
    var isHam = hp.hamCycle(graph, 5);

    System.out.println(isHam);
  }

  boolean isSafe(int v, int graph[][], int[] path, int pos) {
    int prevNode = path[pos - 1];
    if (graph[prevNode][v] == 0) {
      return false;
    }

    for (int i = 0; i < pos; i++) {
      if (path[i] == v) {
        return false;
      }
    }
    return true;
    // return !Arrays.stream(path).limit(pos).anyMatch(x -> x == v);
  }

  boolean isHamCycle(int[][] graph, int[] path, int pos, int V) {
    if (pos == V) {
      int lastNode = path[pos - 1];
      int firstNode = path[0];
      // return isConnected(graph, lastNode, firstNode);
      return graph[lastNode][firstNode] == 1;
    }

    for (int v = 1; v < V; v++) {
      if (isSafe(v, graph, path, pos)) {
        path[pos] = v;
        if (isHamCycle(graph, path, pos, V)) {
          return true;
        }
        path[pos] = -1;
      }
    }
    return false;
  }

  boolean hamCycle(int graph[][], int V) {
    int[] path = new int[V];
    Arrays.fill(path, -1);
    path[0] = 0;
    return isHamCycle(graph, path, 1, V);
  }

  private boolean isConnected(int[][] graph, int nodeA, int nodeB) {
    return graph[nodeA][nodeB] == CONNECTED;
  }
}
