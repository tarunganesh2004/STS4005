import java.util.*;

public class SelectionSort {
  public SelectionSort() {
    super();
  }

  private static void selectionSort(int[] arr, int low, int high) {
    if (low < high) {
      int pivot = getPivot(arr, low, high);
      selectionSort(arr, low, pivot - 1);
      selectionSort(arr, pivot + 1, high);
    }
  }

  private static int getPivot(int[] arr, int low, int high) {
    int pivotP = low;
    int pivLet = arr[high];
    for (int i = low; i <= high; i++) {
      if (pivLet > arr[i]) {
        swap(arr, i, pivotP);
        pivotP++;
      }
    }
    swap(arr, pivotP, high);
    return pivotP;
  }

  public static void swap(int[] arr, int idx, int idx2) {
    int temp = arr[idx];
    arr[idx] = arr[idx2];
    arr[idx2] = temp;
  }

  public static void main(String[] args) {
    var sc = new Scanner(System.in);
    var line = sc.nextLine().split(" ");
    var arr = Arrays.stream(line).mapToInt(Integer::parseInt).toArray();

    int low = 0; int high = arr.length - 1;
    selectionSort(arr, low, high);

    for (int i : arr) {
      System.out.println(i);
    }
  }
}
