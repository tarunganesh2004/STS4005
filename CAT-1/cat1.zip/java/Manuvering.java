import java.util.*; 

public class Manuvering{
  public Manuvering(){ super(); }

  public static int numberOfPaths(int m, int n){
    if(m == 1 || n == 1) {
      return 1;
    }

    return numberOfPaths(m-1, n) + numberOfPaths(m, n-1);
  }

  public static void main(String[] args){
    var sc = new Scanner(System.in);
    var line = sc.nextLine().split(" ");
    int m = Integer.parseInt(line[0]);
    int n = Integer.parseInt(line[1]);
    int res = numberOfPaths(m, n);
    System.out.println(res);
  }
}
