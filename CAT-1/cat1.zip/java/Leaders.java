import java.util.*;

public class Leaders{
  public Leaders(){ super();}
  public static void main(String[] args) {
    // Getting the input
    var sc = new Scanner(System.in);
    var input = sc.nextLine().split(" ");
    // Reading the input 
    int[] arr = Arrays.stream(input).mapToInt(Integer::parseInt).toArray();

    // creating the res vars
    var res = new ArrayList<Integer>();
    int max = Integer.MIN_VALUE;

    // sol loop 
    for(int i = arr.length-1; i > -1; i--){
      int val = arr[i];
      if(val > max){
        max = val; 
        res.add(val);
      }
    }

    // printing the res
    for(int i : res){
      System.out.println(i);
    }
  }
}
