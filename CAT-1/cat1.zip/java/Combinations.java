import java.util.*;

public class Combinations {
  public Combinations() {
    super();
  }

  public static void combinations(int[] arr, int n, int r, int index, int[] data, int i) {
    if (index == r) {
      for (int j = 0; j < r; j++)
        System.out.print(data[j] + " ");
      System.out.println();
      return;
    }
    
    if(i >= n) return; 

    data[index] = arr[i];

    i++;
    combinations(arr, n, r, index+1, data, i);
    combinations(arr, n, r, index, data, i);
  }

  public static void main(String[] args) {
    var sc = new Scanner(System.in);
    var line = sc.nextLine().split(" ");
    int[] arr = Arrays.stream(line).mapToInt(Integer::parseInt).toArray();
    int r = sc.nextInt();
    int[] data = new int[r];
    combinations(arr, arr.length, r, 0, data, 0);
  }
}
