import java.util.*;

public class SelectionSort{
  public SelectionSort(){ super(); }

  public static void selectionSort(int[] arr){
    for(int i = 0; i<arr.length; i++){
      int minIndex = Arrays.stream(arr).skip(i).min().getAsInt();
      int temp = arr[minIndex];
      arr[minIndex] = arr[i];
      arr[i] = temp;
    }
  }

  public static void main(String[] args) {
    // reading the array 
    var sc = new Scanner(System.in);
    var line = sc.nextLine().split(" ");
    var arr = Arrays.stream(line).mapToInt(Integer::parseInt).toArray();
    
    selectionSort(arr);
  }
}
