import java.util.*;

public class NQueens{
  private static int EMPTY = 0;
  private static int QUEEN = 1;

  public NQueens(){
    super();
  }

  private static boolean solveNQueen(int[][] board, int c){
    if(c >= board.length) 
      return true;
    for(int i = 0; i < board.length; i++){
      if(isValidPos(board, i, c)){
        board[i][c] = QUEEN;
        if(solveNQueen(board, c+1)){
          return true;
        }
      }
      board[i][c] = EMPTY;
    }
    return false;
  }

  private static boolean isValidPos(int[][] board, int r, int c){
    int i, j;
    for(i = c; i >= 0; i--){
      if(board[r][i] == QUEEN) 
        return false;
    }

    for(i = r, j = c; i >= 0 && j >= 0; i--, j--){
      if(board[i][j] == QUEEN)
        return false;
    }

    for(i = r, j = c; i < board.length && j >= 0; i++, j--){
      if(board[i][j] == QUEEN)
        return false;
    }

    return true;
  }

  public static void main(String[] args) {
    var sc = new Scanner(System.in);
    int r = sc.nextInt();
    int[][] board = new int[r][r];
    solveNQueen(board, 0);

    for(var row: board){
      for(int i: row){
        System.out.print(i + " ");
      }
      System.out.println();
    }
  }
}
