import java.util.Scanner;
import java.util.Arrays;

public class MaxEqui{
  public MaxEqui(){ super(); } 

  public static void main(String[] args) {
    // take array input in just one line 
    var sc = new Scanner(System.in);
    var line = sc.nextLine().split(" ");
    // convert string array to int array directly using streams
    var arr = Arrays.stream(line).mapToInt(Integer::parseInt).toArray();
    int sum = Arrays.stream(arr).sum();

    int itrSum = 0;
    int res = Integer.MIN_VALUE;
    for (int i = 0; i < arr.length; i++) {
        int val = arr[i];
        itrSum +=  val;
        if(itrSum == sum){
          res = Math.max(res, itrSum);
        }
        sum -= val;
    }

    System.out.println(res);
  }
}
