
import java.util.*;

public class Combi2 {
  public Combi2() {
    super();
  }

  public static void combinations(int[] arr, int[] data, int r, int index, int i){
    if(index == r){
      for(int a: data){
        System.out.print(a);
      }
      System.out.println();
      return;
    }

    if(i >= arr.length) return;
    data[index] = arr[i];

    i++;
    combinations(arr, data, r, index+1, i);
    combinations(arr, data, r, index, i);
  }

  public static void main(String[] args) {
    var sc = new Scanner(System.in);
    var line = sc.nextLine().split(" ");
    int[] arr = Arrays.stream(line).mapToInt(Integer::parseInt).toArray();
    int r = sc.nextInt();
    int[] data = new int[r];
    combinations(arr, data, r, 0, 0);
  }
}
