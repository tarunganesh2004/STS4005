import java.util.*;

public class WarnsdorffAlgo {

  public boolean solveKnightTour(int r, int c, int movesCount) {
    if (movesCount-1 == BOARD_SIZE * BOARD_SIZE)
      return true;

    for (int i = 0; i < movesX.length; i++) {
      int newX = r + movesX[i];
      int newY = c + movesY[i];

      if (!isInBounds(newX))
        continue;
      if (!isInBounds(newY))
        continue;
      if (visited[newX][newY] != NOT_VISITED)
        continue;

      visited[newX][newY] = movesCount;
      if (solveKnightTour(newX, newY, movesCount + 1)) {
        return true;
      }
      visited[newX][newY] = NOT_VISITED;

    }

    return false;
  }

  public static void main(String[] args) {
    var sc = new Scanner(System.in);
    int boardSize = sc.nextInt();

    var kt = new WarnsdorffAlgo(boardSize);
    var isSolved = kt.solveKnightTour(0, 0, 0);
    kt.printWalk();
    System.out.println(isSolved);
  }

  public void printWalk() {
    for (var row : visited) {
      for (int i : row) {
        System.out.print(i + " ");
      }
      System.out.println();
    }
  }

  final int BOARD_SIZE;
  final int[] movesX = { -2, -2, -1, -1, 1, 1, 2, 2 };
  final int[] movesY = { -1, 1, -2, 2, -2, 2, -1, 1 };
  int[][] visited;

  final int NOT_VISITED = 0;
  final int VISITED = 1;

  public WarnsdorffAlgo(int boardSize) {
    super();
    this.BOARD_SIZE = boardSize;
    this.visited = new int[boardSize][boardSize];
  }

  private boolean isInBounds(int a) {
    return a >= 0 && a < BOARD_SIZE;
  }

  private boolean isVisited(int r, int c) {
    return (visited[r][c] != NOT_VISITED);
  }
}
