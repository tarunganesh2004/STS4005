import java.util.*;

public class RatInMaze {
  public RatInMaze() {
    super();
  }

  static int[][] sol;

  public static boolean solveMaze(int[][] maze, int r, int c){
    if(r == maze.length-1 && c == maze[0].length-1) 
      return true;
    
    if( isInBounds(maze, r) && isInBounds(maze, c) ){
      sol[r][c] = 1;
      if(solveMaze(maze, r+1, c)) 
        return true;
      if(solveMaze(maze, r, c+1))
        return true;
      sol[r][c] = 0;
    }
    return false;
  }

  public static void main(String[] args) {
    int[][] maze = {
        { 1, 1, 1, 1, 0 },
        { 0, 0, 0, 1, 1 },
        { 1, 1, 1, 1, 1 },
        { 1, 0, 0, 0, 1 },
        { 1, 1, 1, 1, 1 },
    };
    sol = new int[maze.length][maze[0].length];
    boolean i = solveMaze(maze, 0, 0);
    System.out.println(i);
  }

  private static boolean isInBounds(int[][] maze, int newR) {
    if (newR >= maze.length || newR < 0)
      return false;
    return true;
  }
}
