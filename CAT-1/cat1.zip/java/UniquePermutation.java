import java.util.*;

public class UniquePermutation {
  public UniquePermutation() {
    super();
  }

  public static void permute(char[] arr, int pos, ArrayList<String> res){
    if(pos >= arr.length){
      res.add(new String(arr));
    }

    var addedSet = new HashSet<Character>();
    for(int i = pos; i < arr.length; i++){
      if(addedSet.contains(arr[i])){
        continue;
      }

      addedSet.add(arr[i]);
      swap(arr, pos, i);
      permute(arr, pos+1, res);
      swap(arr, pos, i);
    }
  }

  public static void main(String[] args) {
    var sc = new Scanner(System.in);
    var line = sc.nextLine();
    char[] arr = line.toCharArray();
    Arrays.sort(arr);
    var resList = new ArrayList<String>();
    permute(arr, 0, resList);
    resList.forEach(s -> System.out.println(s));
  }

  private static void swap(char[] arr, int i, int j){
    var temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
  }

  private static void printArray(char[] arr) {
    for (char i : arr) {
      System.out.print(i + " ,");
    }
    System.out.println();
  }

  private static int factorial(int n){
    int res = 1;
    for(int i = 1; i <= n; i++){
      res *= i;
    }
    return res;
  }
}
